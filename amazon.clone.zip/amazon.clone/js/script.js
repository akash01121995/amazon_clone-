

function hello(){
    prompt("this is login form ,please enter your name", "akash");
}
   
